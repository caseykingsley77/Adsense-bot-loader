
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "49.12.196.34",
                    port: parseInt(56534)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "YqIlQp",
                    password: "XrhldJ"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    