
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "159.69.84.69",
                    port: parseInt(49237)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "pTHiwN",
                    password: "Dilv2j"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    