
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "194.163.163.10",
                    port: parseInt(43117)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "S6VEbR",
                    password: "BzcVPL"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    