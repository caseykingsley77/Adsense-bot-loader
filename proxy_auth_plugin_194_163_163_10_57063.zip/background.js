
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "194.163.163.10",
                    port: parseInt(57063)
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {});

    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "nPb1wI",
                    password: "aJgRQo"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ['blocking']
    );
    